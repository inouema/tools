﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace plugin_sample
{
    /// <summary>
    /// 設定データ保存クラス
    /// </summary>
    [Serializable()]
    public class Setting
    {
        /// <summary>
        /// Settingsクラスのただ一つのインスタンス
        /// </summary>
        [NonSerialized()]
        private static Setting _instance;
        /// <summary>
        /// 設定データ保存オブジェクト
        /// </summary>
        [System.Xml.Serialization.XmlIgnore]
        public static Setting DATA
        {
            get
            {
                if (_instance == null)
                    _instance = new Setting();
                return _instance;
            }
            set { _instance = value; }
        }

        public Setting() { }

        [System.Xml.Serialization.XmlIgnore]
        /// <summary>色付け</summary>
        public Color Coloring { get; set; }
        /// <summary>色付け名</summary>
        public string ColoringStr { get; set; }

    }

}
