﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using saezuri.plugin;
using saezuri.NLP;

namespace plugin_sample
{
    public class plugin_sample : IPluginBase, IPlugin
    {
        public plugin_sample()
        {
            // プラグイン名
            this.Name = "第二形態素のチェック(サンプル)";
            // プラグインの詳細説明
            this.Description = "二番目の形態素をチェックします．";
            // プラグインの役割
            this.Role = ROLETYPE.PROOFREADING;
            // チェック機能があるか
            this.EnabledCheck = true;
            // 設定ダイアログがあるか
            this.HasSetupDialog = true;

            // 設定保存
            Setting.DATA = saezuri.CUtility.LoadData<Setting>(string.Format("{0}{1}.xml", IPluginBase.SettingFolder, this.AssemblyName));
            // 色設定がない場合のデフォルト
            if (string.IsNullOrEmpty(Setting.DATA.ColoringStr) == true) { Setting.DATA.ColoringStr = System.Drawing.Color.Red.Name; }
            Setting.DATA.Coloring = System.Drawing.Color.FromName(Setting.DATA.ColoringStr);

        }

        public new List<CCheck> Check(CSentence _SentencesData)
        {
            List<CCheck> checkList = new List<CCheck>();

            if (_SentencesData.MorphemeList.Count >= 2)
            {
                CCheck rev = new CCheck();
                // 元の文
                rev.Text = _SentencesData.Text;
                // 簡易メッセージ
                rev.Message = "これは，サンプルのチェックです(第二形態素)";
                // レベル
                rev.Level = POINTOUTLEVEL.LV1_ATTENTION;
                // 役割
                rev.Role = Role;
                // 指摘対象文字
                CMorpheme _w = _SentencesData.MorphemeList[1];
                rev.TargetText = _w.Text;
                // 指摘対象位置
                CCheck.RangePosition range = new CCheck.RangePosition(_w.Position, _w.Text.Length);
                rev.TargetRange.Add(range);
                // 指摘色
                rev.ForeColor = Setting.DATA.Coloring;
                // 修正候補
                rev.CorrectionList.Add(CNLP.StrConvKata2Hira(_w.Read));
                // 詳細
                rev.Details = string.Format("[{0}] : 第二形態素です", rev.TargetText);
                //rev.DetailsPic;
                // アセンブリ名
                rev.PluginAssembly = this.AssemblyName;
                // 全文対象か
                rev.TargetIsALL = false;

                checkList.Add(rev);
            }

            return checkList;
        }

        public new List<CCheck> Check(CParagraph _ParagraphData)
        {
            List<CCheck> checkList = new List<CCheck>();
            return checkList;
        }

        public new List<CCheck> Check(CDocument _DocumentData)
        {
            List<CCheck> checkList = new List<CCheck>();
            return checkList;
        }

        public new void ShowSetupDialog()
        {
            new frmOption(string.Format("{0}{1}.xml", IPluginBase.SettingFolder, this.AssemblyName)).ShowDialog();
        }

    }
}
