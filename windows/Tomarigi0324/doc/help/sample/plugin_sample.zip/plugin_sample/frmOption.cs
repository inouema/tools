﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace plugin_sample
{
    public partial class frmOption : Form
    {
        string filename = null;

        public frmOption(string _filename)
        {
            filename = _filename;
            InitializeComponent();

            #region // 現設定の取得

            // 指摘色
            foreach (Color c in saezuri.CUtility.ColorList) cmbColor.Items.Add(c); cmbColor.SelectedItem = Setting.DATA.Coloring;

            #endregion

        }

        private void btnOK_Click(object sender, EventArgs e)
        {

            #region // 新設定

            // 色
            Setting.DATA.Coloring = (Color)cmbColor.SelectedItem;
            Setting.DATA.ColoringStr = Setting.DATA.Coloring.Name;

            #endregion

            this.Close();
        }
    }
}
