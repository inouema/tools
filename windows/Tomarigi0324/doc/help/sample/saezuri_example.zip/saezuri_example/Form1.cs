﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using saezuri;
using saezuri.NLP;

namespace saezuri_example
{
    public partial class Form1 : Form
    {
        CDocument doc = null;
        CSentenceView view1 = null;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            string txt = textBox1.Text;

            // 文書を作成
            doc = new CDocument();
            doc.ConvertShortEssay(txt);
            // 各段落を参照
            for (int i = 0; i < doc.ParagraphList.Count; i++)
            {
                MessageBox.Show("第" + (i + 1) + "段落\r\n\r\n" + doc.ParagraphList[i].Text);
            }
            // 文書を構成する文の解析と取得
            CCabocha cabocha = new CCabocha();
            Dictionary<string, string> analyzed = new Dictionary<string, string>();
            foreach (string s in doc.GetALLSentenceTextList())
            {
                string _s = s.Trim(' ', '　', '\t');
                if (cabocha.Analyze(_s) == true)
                {
                    analyzed.Add(_s, cabocha.ResultText);
                }
                listBox1.Items.Add(_s);
            }
            doc.SetOverWrite(analyzed);

            
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex == -1) return;

            List<CSentence> sentences =  doc.GetALLSentenceList();
            CSentence sentence = sentences[listBox1.SelectedIndex];

            StringBuilder sb = new StringBuilder();
            foreach (CSegment _seg in sentence.SegmentList)
            {
                foreach (CMorpheme _mo in _seg.MorphemeList)
                {
                    sb.AppendFormat("{0}({1}) ", _mo.Text, _mo.Pos);
                }
                sb.Append(" / ");
            }
            MessageBox.Show(sb.ToString());

            if (view1 != null) view1.Dispose();
            view1 = new CSentenceView(panel1, sentence);
            view1.Draw();

        }


    }
}
